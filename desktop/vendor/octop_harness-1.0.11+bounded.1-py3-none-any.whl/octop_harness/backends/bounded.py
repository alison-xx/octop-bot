"""Bounded binary reads: unsupported transports fail closed before downloading."""

from __future__ import annotations

import os
import stat
import sys
from pathlib import Path
from typing import Any, BinaryIO


class DownloadTooLargeError(ValueError):
    """A source exceeded the caller's byte budget."""


def read_capped(stream: BinaryIO, limit: int) -> bytes:
    """Consume at most limit + one bytes, even when size metadata is absent."""
    parts: list[bytes] = []
    remaining = limit
    while True:
        chunk = stream.read(min(65536, remaining + 1))
        if not chunk:
            return b"".join(parts)
        remaining -= len(chunk)
        if remaining < 0:
            raise DownloadTooLargeError("file exceeds download limit")
        parts.append(chunk)


def read_workspace_file(root: Path, fragment: str, limit: int) -> bytes | None:
    """Open under the workspace and validate the opened file before reading."""
    try:
        if sys.platform == "win32":
            import ctypes
            import msvcrt

            with (root / fragment).open("rb") as stream:
                get_path = ctypes.windll.kernel32.GetFinalPathNameByHandleW
                handle = ctypes.c_void_p(msvcrt.get_osfhandle(stream.fileno()))
                size = get_path(handle, None, 0, 0)
                if not size:
                    raise ctypes.WinError()
                buf = ctypes.create_unicode_buffer(size)
                copied = get_path(handle, buf, size, 0)
                if not 0 < copied < size:
                    raise OSError("cannot verify the opened workspace file")
                # GetFinalPathNameByHandleW returns an extended-length DOS or UNC path.
                name = buf.value.removeprefix("\\\\?\\")
                if name.startswith("UNC\\"):
                    name = "\\\\" + name[4:]
                Path(name).relative_to(root)
                if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                    raise ValueError("expected a regular file")
                return read_capped(stream, limit)
        parts = Path(fragment).parts
        if not parts or ".." in parts or Path(fragment).is_absolute():
            raise ValueError("expected a workspace-relative file path")
        flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW
        parent = os.open(root, flags)
        try:
            for part in parts[:-1]:
                child = os.open(part, flags, dir_fd=parent)
                os.close(parent)
                parent = child
            fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=parent)
            with os.fdopen(fd, "rb") as stream:
                if not stat.S_ISREG(os.fstat(fd).st_mode):
                    raise ValueError("expected a regular file")
                return read_capped(stream, limit)
        finally:
            os.close(parent)
    except FileNotFoundError:
        return None


def download_bytes_capped(backend: Any, path: str, max_bytes: int, *, wire_limit: int | None = None) -> bytes | None:
    """Read local/composite/cloud sources without an unbounded download fallback."""
    if max_bytes < 0:
        raise ValueError("max_bytes must be nonnegative")
    from deepagents.backends import CompositeBackend

    from octop_harness.backends.cloud_storage_base import CloudStorageBackend

    if isinstance(backend, CompositeBackend):
        child, key = backend._get_backend_and_key(path)
        return download_bytes_capped(child, key, max_bytes, wire_limit=wire_limit)
    if isinstance(backend, CloudStorageBackend):
        import inspect

        if "max_bytes" not in inspect.signature(backend._get_file_data).parameters:
            raise NotImplementedError("cloud backend does not support bounded binary downloads")
        # FileData is a JSON envelope (UTF-8 escaping can expand one byte to six).
        data = backend._get_file_data(path, max_bytes=wire_limit if wire_limit is not None else max_bytes * 6 + 65536)
        if data is None:
            return None
        result = backend._file_data_to_bytes(data)
        if len(result) > max_bytes:
            raise DownloadTooLargeError("file exceeds download limit")
        return result
    from deepagents.backends import FilesystemBackend, LocalShellBackend

    if not isinstance(backend, (FilesystemBackend, LocalShellBackend)):
        raise NotImplementedError("backend does not support bounded binary downloads")
    local = backend._resolve_path(path)
    try:
        with local.open("rb") as stream:
            return read_capped(stream, max_bytes)
    except FileNotFoundError:
        return None

"""Filesystem boundary: path denies, user-owned memory and soft failures.

deepagents ``FilesystemMiddleware`` rejects ``permissions`` when the backend
implements ``SandboxBackendProtocol`` (``local_shell``). Harness still needs
deny rules for read/write filesystem tools there.

Separately, deepagents ``FilesystemBackend._resolve_path`` raises ``ValueError``
for paths outside ``root_dir``, but ``read`` / ``write`` / … only catch
``(OSError, RuntimeError)`` — so the exception escapes ToolNode and aborts the
turn. This middleware softens those into ``ToolMessage(status="error")``.
"""

from __future__ import annotations

import logging
import os
import posixpath
import re
import shlex
from collections.abc import Awaitable, Callable, Iterable
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

from deepagents.backends.utils import validate_path
from deepagents.middleware.filesystem import (
    DeleteSchema,
    EditFileSchema,
    ExecuteSchema,
    FilesystemPermission,
    GlobSchema,
    GrepSchema,
    LsSchema,
    ReadFileSchema,
    ReadVideoFileSchema,
    WriteFileSchema,
)
from langchain.agents.middleware import AgentMiddleware, ModelRequest, ModelResponse
from langchain_core.messages import ToolMessage
from langchain_core.messages.tool import ToolCall
from langchain_core.tools import BaseTool
from langgraph.prebuilt.tool_node import ToolCallRequest
from langgraph.types import Command
from pydantic import BaseModel, Field
from wcmatch import glob as wcglob

from octop_harness.middleware.tool_paths import (
    path_from_tool_args,
    tool_base_name,
    tool_call_meta,
)

if TYPE_CHECKING:
    from octop_harness.backends.workspace import BackendWorkspace

logger = logging.getLogger(__name__)

# Aligned with deepagents.middleware.filesystem._DEFAULT_FS_TOOL_OPS /
# _check_fs_permission / _FS_WCMATCH_FLAGS (private there; mirrored here).
_FS_TOOL_OPS: dict[str, Literal["read", "write"]] = {
    "ls": "read",
    "read_file": "read",
    "glob": "read",
    "grep": "read",
    "write_file": "write",
    "append_file": "write",
    "edit_file": "write",
    "delete": "write",
}
_FS_WCMATCH_FLAGS = wcglob.BRACE | wcglob.GLOBSTAR
_MEMORY_CONTENT_TOOLS = frozenset({"write_file", "edit_file", "append_file"})
_MEMORY_REMOVE_TOOLS = frozenset({"delete", "delete_file", "move_file"})
_MEMORY_WRITE_TOOLS = _MEMORY_CONTENT_TOOLS | _MEMORY_REMOVE_TOOLS
_MEMORY_READ_ONLY_MESSAGE = (
    "{filename} is user-maintained memory. Edit it manually in the memory dashboard. "
    "Use memory_save to remember information in octop-memory."
)
_MEMORY_KEEP_PATH_MESSAGE = (
    "{filename} must stay at its workspace path. Clear it by writing empty content instead of deleting or moving it."
)

_OUTSIDE_ROOT_REMEDIATION = (
    "The path is outside this agent's storage root. "
    "Use a path under the storage root (workspace-relative), or ask the user to "
    "widen the storage root so it contains this path "
    "(on Windows, set an explicit drive path such as D:/octop-data)."
)

_WINDOWS_ABS_RE = re.compile(r"^(?:[A-Za-z]:[\\/]|\\\\)")


def is_windows_absolute_path(raw: str) -> bool:
    """True for leftover ``D:\\…`` / ``D:/…`` / UNC host paths."""
    return bool(_WINDOWS_ABS_RE.match(raw.strip()))


def rewrite_legacy_windows_fs_path(
    raw: str,
    *,
    root_dir: str | Path | None = None,
    workspace_dir: str | Path | None = None,
) -> str:
    """Map a leftover Windows absolute path onto the current storage jail.

    Conversation history and memory often keep ``D:\\octop-data\\…`` after the
    backend root moves (or after migrating off Windows). deepagents virtual
    mode treats that drive-letter string as a relative key; pathlib then jumps
    to the other drive and raises ``Path … outside root directory``, which
    used to abort the whole turn as a generic model-call failure.

    When the same suffix exists under *root_dir* or *workspace_dir*, return a
    jail-safe virtual path (``/data/…``). Otherwise return *raw* unchanged so
    the outside-root soft-fail can explain the storage-root mismatch.
    """
    text = raw.strip()
    if not text or not is_windows_absolute_path(text):
        return raw

    for base in (root_dir, workspace_dir):
        mapped = _virtual_path_if_under_base(text, base)
        if mapped is not None:
            return mapped

    posix = text.replace("\\", "/")
    stripped = posix.split(":", 1)[-1].lstrip("/") if ":" in posix[:3] else posix.lstrip("/")
    parts = [part for part in stripped.split("/") if part]
    bases = [Path(item) for item in (root_dir, workspace_dir) if item]
    for index in range(len(parts)):
        suffix = "/".join(parts[index:])
        for base in bases:
            try:
                candidate = (base.expanduser() / suffix).resolve()
            except OSError:
                continue
            if candidate.is_file() or candidate.is_dir():
                return f"/{suffix}"
    return raw


def _virtual_path_if_under_base(windows_path: str, base: str | Path | None) -> str | None:
    if base is None:
        return None
    try:
        resolved_base = Path(base).expanduser().resolve()
        resolved = Path(windows_path).expanduser().resolve()
        rel = resolved.relative_to(resolved_base).as_posix()
    except (OSError, ValueError):
        return None
    return "/" if not rel or rel == "." else f"/{rel}"


def _normalized_memory_path(path: str) -> str:
    return posixpath.normpath(path.strip().replace("\\", "/")).casefold()


def _is_absolute_path(raw: str) -> bool:
    text = raw.strip()
    return text.startswith(("/", "~")) or is_windows_absolute_path(text)


def _relative_to_base(path: str, base_dir: str) -> str:
    """Join a caller-selected base directory without changing backend semantics."""
    return posixpath.normpath(posixpath.join(base_dir.strip().replace("\\", "/"), path.strip().replace("\\", "/")))


# Shown to the model only. deepagents still requires an absolute path at execution;
# ``_resolve_relative_paths`` consumes these fields before that validation.
_RELATIVE_PATH_DESCRIPTION = (
    "Path to use. An absolute path is used unchanged. "
    "A relative path resolves from base_dir when that is set, otherwise from the workspace."
)
_OPTIONAL_RELATIVE_PATH_DESCRIPTION = (
    "Directory to search. An absolute path is used unchanged. "
    "A relative path resolves from base_dir when that is set, otherwise from the workspace. "
    "Omit to search the workspace."
)
_BASE_DIR_DESCRIPTION = (
    "Absolute directory for a relative path. "
    "Pass the containing directory of a file when following a relative reference inside it. "
    "Omit for an absolute path or a workspace-relative path."
)
_CWD_DESCRIPTION = (
    "Absolute directory for this command only. "
    "Pass a file's containing directory when the command must run beside that file. "
    "Omit to run in the workspace. Later commands are unaffected."
)


class _LsCallSchema(LsSchema):
    path: str = Field(description=_RELATIVE_PATH_DESCRIPTION)
    base_dir: str | None = Field(default=None, description=_BASE_DIR_DESCRIPTION)


class _ReadFileCallSchema(ReadFileSchema):
    file_path: str = Field(description=_RELATIVE_PATH_DESCRIPTION)
    base_dir: str | None = Field(default=None, description=_BASE_DIR_DESCRIPTION)


class _ReadVideoFileCallSchema(ReadVideoFileSchema):
    file_path: str = Field(description=_RELATIVE_PATH_DESCRIPTION)
    base_dir: str | None = Field(default=None, description=_BASE_DIR_DESCRIPTION)


class _WriteFileCallSchema(WriteFileSchema):
    file_path: str = Field(description=_RELATIVE_PATH_DESCRIPTION)
    base_dir: str | None = Field(default=None, description=_BASE_DIR_DESCRIPTION)


class _EditFileCallSchema(EditFileSchema):
    file_path: str = Field(description=_RELATIVE_PATH_DESCRIPTION)
    base_dir: str | None = Field(default=None, description=_BASE_DIR_DESCRIPTION)


class _DeleteCallSchema(DeleteSchema):
    file_path: str = Field(description=_RELATIVE_PATH_DESCRIPTION)
    base_dir: str | None = Field(default=None, description=_BASE_DIR_DESCRIPTION)


class _GlobCallSchema(GlobSchema):
    path: str | None = Field(default=None, description=_OPTIONAL_RELATIVE_PATH_DESCRIPTION)
    base_dir: str | None = Field(default=None, description=_BASE_DIR_DESCRIPTION)


class _GrepCallSchema(GrepSchema):
    path: str | None = Field(default=None, description=_OPTIONAL_RELATIVE_PATH_DESCRIPTION)
    base_dir: str | None = Field(default=None, description=_BASE_DIR_DESCRIPTION)


class _ExecuteCallSchema(ExecuteSchema):
    cwd: str | None = Field(default=None, description=_CWD_DESCRIPTION)


_CALL_SCHEMAS: dict[str, type[BaseModel]] = {
    "ls": _LsCallSchema,
    "read_file": _ReadFileCallSchema,
    "write_file": _WriteFileCallSchema,
    "edit_file": _EditFileCallSchema,
    "delete": _DeleteCallSchema,
    "glob": _GlobCallSchema,
    "grep": _GrepCallSchema,
    "execute": _ExecuteCallSchema,
}
_ANNOTATED_SCHEMAS = frozenset(_CALL_SCHEMAS.values()) | {_ReadVideoFileCallSchema}


_SOURCE_SCHEMAS: dict[str, type[BaseModel]] = {
    "ls": LsSchema,
    "read_file": ReadFileSchema,
    "write_file": WriteFileSchema,
    "edit_file": EditFileSchema,
    "delete": DeleteSchema,
    "glob": GlobSchema,
    "grep": GrepSchema,
    "execute": ExecuteSchema,
}


def _call_schema_for(tool_name: str, schema: Any) -> type[BaseModel] | None:
    """Schema the model should see for one filesystem or execute tool."""
    if not isinstance(schema, type) or not issubclass(schema, BaseModel):
        return None
    if schema in _ANNOTATED_SCHEMAS:
        return None
    base = tool_base_name(tool_name)
    if base == "read_file" and issubclass(schema, ReadVideoFileSchema):
        return _ReadVideoFileCallSchema
    source = _SOURCE_SCHEMAS.get(base)
    if source is not None and issubclass(schema, source):
        return _CALL_SCHEMAS[base]
    return None


def _with_document_base_schema(tool: Any) -> Any:
    """Copy a tool so the model can pass a document-relative base.

    The live tool keeps deepagents' schema. Request copies advertise ``base_dir``
    or ``cwd``; the guard removes those arguments before the tool runs.
    """
    if not isinstance(tool, BaseTool):
        return tool
    schema = _call_schema_for(str(tool.name or ""), tool.args_schema)
    if schema is None:
        return tool
    return tool.model_copy(update={"args_schema": schema})


def _annotate_filesystem_tools(request: ModelRequest) -> ModelRequest:
    tools = list(request.tools or [])
    rewritten = [_with_document_base_schema(tool) for tool in tools]
    if all(updated is original for updated, original in zip(rewritten, tools, strict=True)):
        return request
    return request.override(tools=rewritten)


def _realpath_if_available(path: str) -> str | None:
    try:
        if os.path.lexists(path):
            return os.path.realpath(path)
    except OSError:
        return None
    return None


def _expand_path_candidates(path: str) -> tuple[str, ...]:
    """Path forms to match against deny/allow patterns.

    Includes the logical path and its realpath (macOS ``/etc`` → ``/private/etc``).
    """
    out: list[str] = [path]
    real = _realpath_if_available(path)
    if real and real not in out:
        out.append(real)
    return tuple(out)


def _expand_patterns(pattern: str) -> tuple[str, ...]:
    """Expand one policy pattern so directory roots are covered.

    ``/etc/**`` must also match ``/etc`` itself (``ls /etc``). When the prefix
    resolves through a symlink (macOS), also match the realpath forms.
    """
    patterns: list[str] = [pattern]
    if pattern.endswith("/**"):
        prefix = pattern[:-3]
        if prefix and prefix not in patterns:
            patterns.append(prefix)
        real_prefix = _realpath_if_available(prefix) if prefix else None
        if real_prefix:
            if real_prefix not in patterns:
                patterns.append(real_prefix)
            real_glob = f"{real_prefix}/**"
            if real_glob not in patterns:
                patterns.append(real_glob)
    return tuple(patterns)


def _path_matches_patterns(path: str, patterns: Iterable[str]) -> bool:
    for candidate in _expand_path_candidates(path):
        for pattern in patterns:
            for expanded in _expand_patterns(pattern):
                if wcglob.globmatch(candidate, expanded, flags=_FS_WCMATCH_FLAGS):
                    return True
    return False


def _check_fs_permission(
    rules: list[FilesystemPermission],
    operation: Literal["read", "write"],
    path: str,
) -> Literal["allow", "deny", "interrupt"]:
    """First-match path rule — directory roots and symlink aliases included."""
    for rule in rules:
        if operation not in rule.operations:
            continue
        if _path_matches_patterns(path, rule.paths):
            return rule.mode
    return "allow"


_BASENAME_WIDE_GLOBS = frozenset({"*", "**", "**/*"})
_GLOB_PATH_MESSAGE = (
    "Error: glob pattern {pattern!r} needs an explicit path. "
    "A relative path such as '.' is this workspace; path='/' searches from the backend root."
)
_GLOB_ESCAPE_MESSAGE = (
    "Error: glob path {path!r} leaves the workspace. "
    "Use a workspace-relative path, or path='/' to search from the backend root."
)


def _basename_wide_glob(pattern: str) -> bool:
    """True when omitting ``path`` would walk every depth from the backend root."""
    normalized = pattern.strip().replace("\\", "/")
    return normalized in _BASENAME_WIDE_GLOBS or "/" not in normalized


def _explicit_glob_root(path: str) -> bool:
    """``/`` and other absolute paths choose a search root on purpose."""
    return path.strip().replace("\\", "/").startswith("/") or is_windows_absolute_path(path)


def _relative_glob_leaves_workspace(path: str, workspace: BackendWorkspace) -> bool:
    try:
        workspace_root = Path(workspace.resolve_path(".")).resolve()
        target = Path(workspace.resolve_path(path)).resolve()
        target.relative_to(workspace_root)
    except (OSError, PermissionError, ValueError):
        return True
    return False


def unbounded_glob_block_reason(
    tool_name: str,
    params: dict[str, Any],
    *,
    workspace: BackendWorkspace | None = None,
) -> str | None:
    """Require an explicit search root for basename-wide glob patterns.

    A pattern without ``/`` matches the file name at every depth. With no path,
    deepagents starts that walk at the backend root. A relative path stays in
    the workspace; ``/`` is an explicit backend-root search. A pattern that
    already contains ``/``, such as ``**/*.md``, is root-relative and is left
    to the backend.
    """
    pattern = params.get("pattern")
    if tool_base_name(tool_name) != "glob" or not isinstance(pattern, str):
        return None
    normalized = pattern.strip()
    if not _basename_wide_glob(normalized):
        return None
    path = params.get("path")
    if not isinstance(path, str) or not path.strip():
        return _GLOB_PATH_MESSAGE.format(pattern=normalized)
    if _explicit_glob_root(path):
        return None
    if workspace is not None and _relative_glob_leaves_workspace(path, workspace):
        return _GLOB_ESCAPE_MESSAGE.format(path=path.strip())
    return None


def filesystem_guard_block_reason(
    permissions: list[FilesystemPermission],
    *,
    tool_name: str,
    params: dict[str, Any],
) -> str | None:
    """Return a rejection message when *tool_name* is denied by *permissions*.

    Matched sensitive paths refuse access for read/write filesystem tools
    (``ls``, ``read_file``, ``glob``, ``grep``, ``write_file``, ``edit_file``).
    """
    if not permissions:
        return None
    base = tool_base_name(tool_name)
    operation = _FS_TOOL_OPS.get(base)
    if operation is None:
        return None
    raw_path = path_from_tool_args(tool_name, params)
    if raw_path is None:
        return None
    try:
        validated_path = validate_path(raw_path)
    except ValueError:
        return None
    if _check_fs_permission(permissions, operation, validated_path) == "deny":
        return f"Error: permission denied for {operation} on {validated_path}"
    return None


def is_path_outside_root_error(exc: BaseException) -> bool:
    """True when *exc* is the deepagents virtual-path jail ``ValueError``."""
    if not isinstance(exc, ValueError):
        return False
    lower = str(exc).lower()
    return "outside root directory" in lower or "path traversal not allowed" in lower


def path_outside_root_tool_message(
    *,
    tool_name: str,
    tool_call_id: str,
    exc: BaseException,
) -> ToolMessage:
    """Build a model-visible tool error for an outside-root failure."""
    return ToolMessage(
        content=f"Error: {exc}. {_OUTSIDE_ROOT_REMEDIATION}",
        name=tool_name or "tool",
        tool_call_id=tool_call_id,
        status="error",
    )


class FilesystemGuardMiddleware(AgentMiddleware[Any, Any]):
    """Filesystem tool boundary: user-owned memory, denies and soft failures.

    When a workspace is bound and user-memory protection is on, MEMORY.md / USER.md
    writes are blocked. Protection follows structured memory: on means the user
    edits those files and the agent uses memory_save; off means content edits are
    allowed. Delete and move stay blocked so the loader paths remain. This is
    independent of optional permission rules and shell-command guard settings.
    Outside-root softening applies only to filesystem tools (``ls``,
    ``read_file``, …), not arbitrary tool ValueErrors.
    """

    def __init__(
        self,
        permissions: list[FilesystemPermission] | None = None,
        *,
        root_dir: str | Path | None = None,
        workspace_dir: str | Path | None = None,
        workspace: BackendWorkspace | None = None,
        protect_user_memory: bool = True,
    ) -> None:
        self._permissions = list(permissions or ())
        self._root_dir = root_dir
        self._workspace_dir = workspace_dir
        self._workspace = workspace
        self._protect_user_memory = protect_user_memory
        self._rewritten_logged: set[str] = set()

    def _execution_backend(self) -> Any:
        workspace = self._workspace
        if workspace is None:
            return None
        return getattr(workspace, "backend", None)

    def _uses_virtual_tool_root(self) -> bool:
        """True when filesystem tools address a rootfs, not the host workspace.

        Docker and OpenSandbox set ``sandbox_fs``. bubblewrap sets
        ``virtual_tool_root``. Relative paths stay under ``/`` so each backend
        maps them into its own workspace.
        """
        backend = self._execution_backend()
        if backend is None:
            return False
        return bool(getattr(backend, "sandbox_fs", False) or getattr(backend, "virtual_tool_root", False))

    def _relative_root(self) -> str:
        guest_workspace = getattr(self._execution_backend(), "sandbox_workspace_dir", None)
        if isinstance(guest_workspace, str):
            return guest_workspace
        if self._uses_virtual_tool_root():
            return "/"
        return str(self._workspace_dir or ".")

    def _shell_cwd(self, path: str) -> str:
        """Turn an agent-facing cwd into the path the shell should ``cd`` to."""
        backend = self._execution_backend()
        mapper = getattr(backend, "shell_path", None) if backend is not None else None
        if not callable(mapper):
            return path
        mapped = mapper(path)
        if isinstance(mapped, str) and mapped.strip():
            return mapped.strip()
        return path

    def _rewrite_legacy_windows_request(self, request: ToolCallRequest) -> ToolCallRequest:
        tool_name, _ = tool_call_meta(request)
        raw_args: Any = request.tool_call.get("args") or {}
        path = (
            path_from_tool_args(tool_name, raw_args)
            if tool_base_name(tool_name) in _FS_TOOL_OPS and isinstance(raw_args, dict)
            else None
        )
        rewritten = (
            rewrite_legacy_windows_fs_path(
                path,
                root_dir=self._root_dir,
                workspace_dir=self._workspace_dir,
            )
            if path
            else None
        )
        if not path or rewritten is None or rewritten == path:
            return request
        new_args: dict[str, Any] = dict(raw_args)
        key = next((name for name in ("file_path", "path") if new_args.get(name) == path), None)
        if key is None:
            return request
        new_args[key] = rewritten
        if path not in self._rewritten_logged:
            self._rewritten_logged.add(path)
            logger.debug("FilesystemGuard rewrote leftover Windows path %s -> %s", path, rewritten)
        new_call: ToolCall = {
            "name": str(request.tool_call.get("name") or ""),
            "args": new_args,
            "id": request.tool_call.get("id"),
        }
        if request.tool_call.get("type") == "tool_call":
            new_call["type"] = "tool_call"
        override = getattr(request, "override", None)
        if callable(override):
            updated = override(tool_call=new_call)
            if isinstance(updated, ToolCallRequest):
                return updated
        request.tool_call = new_call
        return request

    def _resolve_relative_paths(  # noqa: PLR0911, PLR0912
        self, request: ToolCallRequest
    ) -> ToolCallRequest | ToolMessage:
        """Consume harness-only ``base_dir`` / ``cwd`` before upstream validation.

        Relative paths otherwise have deepagents' existing backend-root
        semantics.  This opt-in layer provides an unambiguous document-relative
        alternative without mutable session cwd state.
        """
        tool_name, call_id = tool_call_meta(request)
        base = tool_base_name(tool_name)
        raw_args: Any = request.tool_call.get("args") or {}
        if not isinstance(raw_args, dict):
            return request
        args = dict(raw_args)
        changed = False

        if base == "execute":
            cwd = args.pop("cwd", None)
            if cwd is None:
                return request
            if not isinstance(cwd, str) or not cwd.strip():
                return ToolMessage(
                    content="Error: execute cwd must be a non-empty path.",
                    name=tool_name or "execute",
                    tool_call_id=call_id,
                    status="error",
                )
            resolved_cwd = cwd.strip()
            if not _is_absolute_path(resolved_cwd):
                resolved_cwd = _relative_to_base(resolved_cwd, self._relative_root())
            resolved_cwd = self._shell_cwd(resolved_cwd)
            command = args.get("command")
            if not isinstance(command, str):
                return ToolMessage(
                    content="Error: execute command must be a string.",
                    name=tool_name or "execute",
                    tool_call_id=call_id,
                    status="error",
                )
            args["command"] = f"cd -- {shlex.quote(resolved_cwd)} && {command}"
            changed = True
        elif base in _FS_TOOL_OPS:
            base_dir = args.pop("base_dir", None)
            if base_dir is not None and (not isinstance(base_dir, str) or not base_dir.strip()):
                return ToolMessage(
                    content="Error: base_dir must be a non-empty path.",
                    name=tool_name or "tool",
                    tool_call_id=call_id,
                    status="error",
                )
            key = next(
                (name for name in ("file_path", "path") if isinstance(args.get(name), str) and str(args[name]).strip()),
                None,
            )
            # An omitted glob/grep root used to search the backend root. The
            # workspace is the stable default for ordinary project searches.
            if (
                key is None
                and base in {"glob", "grep"}
                and (self._workspace_dir is not None or self._uses_virtual_tool_root())
            ):
                key = "path"
                args[key] = self._relative_root()
                changed = True
            if key is not None:
                path = str(args[key]).strip()
                if not _is_absolute_path(path):
                    root = str(base_dir).strip() if isinstance(base_dir, str) else self._relative_root()
                    args[key] = _relative_to_base(path, root)
                    changed = True
            changed = changed or base_dir is not None

        if not changed:
            return request
        new_call: ToolCall = {
            "name": tool_name,
            "args": args,
            "id": request.tool_call.get("id"),
        }
        if request.tool_call.get("type") == "tool_call":
            new_call["type"] = "tool_call"
        override = getattr(request, "override", None)
        if callable(override):
            updated = override(tool_call=new_call)
            if isinstance(updated, ToolCallRequest):
                return updated
        request.tool_call = new_call
        return request

    def _memory_write_block_reason(self, tool_name: str, params: dict[str, Any]) -> str | None:
        workspace = self._workspace
        if workspace is None or tool_base_name(tool_name) not in _MEMORY_WRITE_TOOLS:
            return None
        protected: dict[str, str] = {}
        for filename in ("MEMORY.md", "USER.md"):
            canonical = workspace.system_rel(filename)
            for path in (filename, f"/{filename}", canonical, f"/{canonical}", workspace.resolve_path(filename)):
                protected[_normalized_memory_path(path)] = filename
        for key in ("file_path", "path", "source", "destination"):
            raw = params.get(key)
            if not isinstance(raw, str):
                continue
            matched_filename = protected.get(_normalized_memory_path(raw))
            if matched_filename is None:
                try:
                    matched_filename = protected.get(_normalized_memory_path(workspace.resolve_path(raw)))
                except (OSError, ValueError, PermissionError):
                    continue
            if matched_filename is not None:
                if not self._protect_user_memory and tool_base_name(tool_name) in _MEMORY_CONTENT_TOOLS:
                    return None
                if not self._protect_user_memory:
                    return _MEMORY_KEEP_PATH_MESSAGE.format(filename=matched_filename)
                return _MEMORY_READ_ONLY_MESSAGE.format(filename=matched_filename)
        return None

    def _blocked_message(self, request: ToolCallRequest) -> ToolMessage | None:
        tool_name, call_id = tool_call_meta(request)
        raw_args: Any = request.tool_call.get("args") or {}
        params: dict[str, Any] = raw_args if isinstance(raw_args, dict) else {}
        reason = (
            unbounded_glob_block_reason(tool_name, params, workspace=self._workspace)
            or self._memory_write_block_reason(tool_name, params)
            or filesystem_guard_block_reason(
                self._permissions,
                tool_name=tool_name,
                params=params,
            )
        )
        if reason is None:
            return None
        logger.info("FilesystemGuard blocked %s", tool_name)
        return ToolMessage(
            content=reason,
            name=tool_name or "tool",
            tool_call_id=call_id,
            status="error",
        )

    def _soften_outside_root(
        self,
        request: ToolCallRequest,
        exc: ValueError,
    ) -> ToolMessage | None:
        if not is_path_outside_root_error(exc):
            return None
        tool_name, call_id = tool_call_meta(request)
        if tool_base_name(tool_name) not in _FS_TOOL_OPS:
            return None
        logger.info("FilesystemGuard softened outside-root %s: %s", tool_name, exc)
        return path_outside_root_tool_message(
            tool_name=tool_name,
            tool_call_id=call_id,
            exc=exc,
        )

    def wrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], ModelResponse],
    ) -> ModelResponse:
        return handler(_annotate_filesystem_tools(request))

    async def awrap_model_call(
        self,
        request: ModelRequest,
        handler: Callable[[ModelRequest], Awaitable[ModelResponse]],
    ) -> ModelResponse:
        return await handler(_annotate_filesystem_tools(request))

    async def awrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], Awaitable[ToolMessage | Command[Any]]],
    ) -> ToolMessage | Command[Any]:
        resolved = self._resolve_relative_paths(request)
        if isinstance(resolved, ToolMessage):
            return resolved
        request = self._rewrite_legacy_windows_request(resolved)
        blocked = self._blocked_message(request)
        if blocked is not None:
            return blocked
        try:
            return await handler(request)
        except ValueError as exc:
            softened = self._soften_outside_root(request, exc)
            if softened is not None:
                return softened
            raise

    def wrap_tool_call(
        self,
        request: ToolCallRequest,
        handler: Callable[[ToolCallRequest], ToolMessage | Command[Any]],
    ) -> ToolMessage | Command[Any]:
        resolved = self._resolve_relative_paths(request)
        if isinstance(resolved, ToolMessage):
            return resolved
        request = self._rewrite_legacy_windows_request(resolved)
        blocked = self._blocked_message(request)
        if blocked is not None:
            return blocked
        try:
            return handler(request)
        except ValueError as exc:
            softened = self._soften_outside_root(request, exc)
            if softened is not None:
                return softened
            raise


__all__ = [
    "FilesystemGuardMiddleware",
    "filesystem_guard_block_reason",
    "is_path_outside_root_error",
    "is_windows_absolute_path",
    "path_outside_root_tool_message",
    "rewrite_legacy_windows_fs_path",
    "unbounded_glob_block_reason",
]
